#!/usr/bin/env python3
"""
Main Node: Lane Detection + Sign Detection + Autonomous Parking
Integrated system for autonomous mobile robot

Features:
- Lane following with PD control
- Traffic sign detection with TensorRT
- AprilTag detection for parking zones
- Ultrasonic obstacle detection
- Encoder-based odometry
- State machine parallel parking
"""

# Display toggle
SHOW_DISPLAY = False

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from sensor_msgs.msg import Image
from std_msgs.msg import Int8, Int32, Float32
from cv_bridge import CvBridge
import cv2
import numpy as np
import time
import os

# Project imports
from config import (RobotConfig, SensorConfig, ParkingConfig, 
                   SpeedConfig, TopicConfig)
from parking_controller import ParkingController, ParkingState

# TensorRT (optional)
try:
    import tensorrt as trt
    import pycuda.driver as cuda
    import pycuda.autoinit
    TRT_AVAILABLE = True
except ImportError:
    TRT_AVAILABLE = False

# AprilTag (optional)
try:
    from dt_apriltags import Detector as AprilTagDetector
    APRILTAG_AVAILABLE = True
except ImportError:
    APRILTAG_AVAILABLE = False


class TRTInference:
    """TensorRT inference wrapper for sign detection"""
    
    def __init__(self, engine_path):
        if not TRT_AVAILABLE:
            raise RuntimeError("TensorRT not available")
            
        self.logger = trt.Logger(trt.Logger.WARNING)
        with open(engine_path, "rb") as f:
            runtime = trt.Runtime(self.logger)
            self.engine = runtime.deserialize_cuda_engine(f.read())
        
        self.context = self.engine.create_execution_context()
        self.stream = cuda.Stream()
        self.inputs = []
        self.outputs = []
        
        for i in range(self.engine.num_io_tensors):
            name = self.engine.get_tensor_name(i)
            shape = self.engine.get_tensor_shape(name)
            dtype = trt.nptype(self.engine.get_tensor_dtype(name))
            size = 1
            for dim in shape:
                size *= abs(dim)
            host_mem = cuda.pagelocked_empty(size, dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)
            
            if self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT:
                self.inputs.append({
                    'host': host_mem, 
                    'device': device_mem, 
                    'name': name, 
                    'shape': shape
                })
            else:
                self.outputs.append({
                    'host': host_mem, 
                    'device': device_mem, 
                    'name': name, 
                    'shape': shape
                })

    def infer(self, input_data):
        np.copyto(self.inputs[0]['host'], input_data.ravel())
        cuda.memcpy_htod_async(
            self.inputs[0]['device'], 
            self.inputs[0]['host'], 
            self.stream
        )
        for inp in self.inputs:
            self.context.set_tensor_address(inp['name'], int(inp['device']))
        for out in self.outputs:
            self.context.set_tensor_address(out['name'], int(out['device']))
        self.context.execute_async_v3(stream_handle=self.stream.handle)
        for out in self.outputs:
            cuda.memcpy_dtoh_async(out['host'], out['device'], self.stream)
        self.stream.synchronize()
        return [out['host'].reshape(out['shape']) for out in self.outputs]


class MainNode(Node):
    """Main integrated node for autonomous robot"""
    
    def __init__(self):
        super().__init__('main_node')
        
        # Configuration
        self.robot_config = RobotConfig()
        self.sensor_config = SensorConfig()
        self.parking_config = ParkingConfig()
        self.speed_config = SpeedConfig()
        
        # QoS
        realtime_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # Subscribers
        # ═══════════════════════════════════════════════════════════════════
        
        self.camera_sub = self.create_subscription(
            Image,
            TopicConfig.CAMERA_TOPIC,
            self.camera_callback,
            10
        )
        
        self.ultrasonic_sub = self.create_subscription(
            Float32,
            TopicConfig.ULTRASONIC_TOPIC,
            self.ultrasonic_callback,
            realtime_qos
        )
        
        self.odometry_sub = self.create_subscription(
            Float32,
            TopicConfig.ODOMETRY_DISTANCE_TOPIC,
            self.odometry_callback,
            realtime_qos
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # Publishers
        # ═══════════════════════════════════════════════════════════════════
        
        self.servo_pub = self.create_publisher(
            Int8,
            TopicConfig.SERVO_TOPIC,
            realtime_qos
        )
        
        self.speed_pub = self.create_publisher(
            Int8,
            TopicConfig.MOTOR_TOPIC,
            realtime_qos
        )
        
        self.odom_reset_pub = self.create_publisher(
            Int32,
            TopicConfig.ODOMETRY_RESET_TOPIC,
            10
        )
        
        # ═══════════════════════════════════════════════════════════════════
        # CV Bridge
        # ═══════════════════════════════════════════════════════════════════
        
        self.bridge = CvBridge()
        
        # ═══════════════════════════════════════════════════════════════════
        # Sensor Data
        # ═══════════════════════════════════════════════════════════════════
        
        self.ultrasonic_distance = float('inf')
        self.odometry_distance = 0.0
        
        # ═══════════════════════════════════════════════════════════════════
        # Operating Mode
        # ═══════════════════════════════════════════════════════════════════
        
        self.mode = 'lane_following'  # 'lane_following' or 'parking'
        
        # ═══════════════════════════════════════════════════════════════════
        # Parking Controller
        # ═══════════════════════════════════════════════════════════════════
        
        self.parking_controller = ParkingController(self.get_logger())
        
        # ═══════════════════════════════════════════════════════════════════
        # AprilTag Detector
        # ═══════════════════════════════════════════════════════════════════
        
        self.apriltag_detector = None
        if APRILTAG_AVAILABLE:
            try:
                self.apriltag_detector = AprilTagDetector(
                    families='tag36h11',
                    nthreads=2,
                    quad_decimate=2.0
                )
                self.get_logger().info("AprilTag detector initialized")
            except Exception as e:
                self.get_logger().warn(f"AprilTag init failed: {e}")
        
        # ═══════════════════════════════════════════════════════════════════
        # Sign Detector (TensorRT)
        # ═══════════════════════════════════════════════════════════════════
        
        self.trt_engine = None
        engine_path = "/home/jetson/Desktop/anti/best.engine"
        if TRT_AVAILABLE and os.path.exists(engine_path):
            try:
                self.trt_engine = TRTInference(engine_path)
                self.get_logger().info("TensorRT engine loaded")
            except Exception as e:
                self.get_logger().warn(f"TensorRT load failed: {e}")
        
        # ═══════════════════════════════════════════════════════════════════
        # Control State
        # ═══════════════════════════════════════════════════════════════════
        
        self.last_servo = None
        self.last_speed = None
        
        # Stop sign handling
        self.stop_sign_active = False
        self.last_stop_time = 0.0
        self.STOP_TIMEOUT = 5.0
        
        # ═══════════════════════════════════════════════════════════════════
        # Display
        # ═══════════════════════════════════════════════════════════════════
        
        if SHOW_DISPLAY:
            cv2.namedWindow('Robot View', cv2.WINDOW_NORMAL)
        
        self.get_logger().info("=" * 50)
        self.get_logger().info("Main Node Started")
        self.get_logger().info(f"  Mode: {self.mode}")
        self.get_logger().info(f"  TensorRT: {TRT_AVAILABLE}")
        self.get_logger().info(f"  AprilTag: {APRILTAG_AVAILABLE}")
        self.get_logger().info("=" * 50)

    # ═══════════════════════════════════════════════════════════════════════
    # SENSOR CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════
    
    def ultrasonic_callback(self, msg: Float32):
        """Receive ultrasonic distance"""
        self.ultrasonic_distance = msg.data

    def odometry_callback(self, msg: Float32):
        """Receive odometry distance"""
        self.odometry_distance = msg.data

    # ═══════════════════════════════════════════════════════════════════════
    # CONTROL COMMANDS
    # ═══════════════════════════════════════════════════════════════════════
    
    def send_servo(self, angle: int):
        """Send steering command"""
        angle = max(-6, min(6, int(angle)))
        if angle != self.last_servo:
            msg = Int8()
            msg.data = angle
            self.servo_pub.publish(msg)
            self.last_servo = angle

    def send_speed(self, speed: int):
        """Send speed command"""
        speed = max(-15, min(15, int(speed)))
        if speed != self.last_speed:
            msg = Int8()
            msg.data = speed
            self.speed_pub.publish(msg)
            self.last_speed = speed

    def reset_odometry(self):
        """Reset trip distance"""
        msg = Int32()
        msg.data = 1
        self.odom_reset_pub.publish(msg)

    # ═══════════════════════════════════════════════════════════════════════
    # APRILTAG DETECTION
    # ═══════════════════════════════════════════════════════════════════════
    
    def detect_parking_tag(self, frame) -> bool:
        """Check for parking AprilTag"""
        if self.apriltag_detector is None:
            return False
        
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            detections = self.apriltag_detector.detect(gray)
            
            for det in detections:
                if det.tag_id == self.parking_config.PARKING_TAG_ID:
                    return True
        except:
            pass
        
        return False

    # ═══════════════════════════════════════════════════════════════════════
    # MAIN CAMERA CALLBACK
    # ═══════════════════════════════════════════════════════════════════════
    
    def camera_callback(self, msg: Image):
        """Main processing loop"""
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            current_time = time.time()
            
            # Check for parking tag
            parking_tag_visible = self.detect_parking_tag(frame)
            
            if parking_tag_visible and self.mode != 'parking':
                self.get_logger().info("PARKING TAG DETECTED - Switching to parking mode")
                self.mode = 'parking'
                self.reset_odometry()
                self.parking_controller.enable()
            
            # Process based on mode
            if self.mode == 'parking':
                # Parking mode
                steering, speed = self.parking_controller.update(
                    self.ultrasonic_distance,
                    self.odometry_distance,
                    parking_tag_visible
                )
                
                self.send_servo(steering)
                
                if self.stop_sign_active:
                    self.send_speed(0)
                else:
                    self.send_speed(speed)
                
                # Check if parking completed
                if self.parking_controller.is_completed():
                    self.get_logger().info("Parking completed - Returning to lane following")
                    self.mode = 'lane_following'
                elif self.parking_controller.is_failed():
                    self.get_logger().warn("Parking failed - Returning to lane following")
                    self.mode = 'lane_following'
            
            else:
                # Lane following mode (simplified)
                # In real implementation, add full lane detection here
                self.send_servo(0)
                self.send_speed(self.speed_config.STRAIGHT_SPEED)
            
            # Display
            if SHOW_DISPLAY:
                self.draw_display(frame)
                key = cv2.waitKey(1) & 0xFF
                if key == 27:  # ESC
                    rclpy.shutdown()
                elif key == ord('p'):
                    self.mode = 'parking'
                    self.reset_odometry()
                    self.parking_controller.enable()
                elif key == ord('l'):
                    self.mode = 'lane_following'
                    self.parking_controller.disable()
                    
        except Exception as e:
            self.get_logger().error(f"Error: {e}")

    # ═══════════════════════════════════════════════════════════════════════
    # DISPLAY
    # ═══════════════════════════════════════════════════════════════════════
    
    def draw_display(self, frame):
        """Draw status overlay"""
        display = frame.copy()
        
        # Status panel
        cv2.rectangle(display, (0, 0), (300, 150), (0, 0, 0), -1)
        
        y = 25
        cv2.putText(display, f"Mode: {self.mode.upper()}", (10, y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        y += 25
        cv2.putText(display, f"Ultrasonic: {self.ultrasonic_distance:.1f} cm", (10, y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        y += 25
        cv2.putText(display, f"Odometry: {self.odometry_distance:.1f} cm", (10, y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        if self.mode == 'parking':
            status = self.parking_controller.get_status()
            y += 25
            cv2.putText(display, f"State: {status['state']}", (10, y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 2)
            y += 25
            cv2.putText(display, f"Space: {status['space_size']:.1f} cm", (10, y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 2)
        
        cv2.imshow('Robot View', display)


def main(args=None):
    rclpy.init(args=args)
    node = MainNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop robot
        try:
            msg = Int8()
            msg.data = 0
            node.speed_pub.publish(msg)
            node.servo_pub.publish(msg)
        except:
            pass
        
        node.destroy_node()
        cv2.destroyAllWindows()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()