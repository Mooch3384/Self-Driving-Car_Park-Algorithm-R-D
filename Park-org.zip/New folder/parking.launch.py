#!/usr/bin/env python3
"""
Launch file for autonomous parking robot
Starts all necessary nodes
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        
        # Odometry Node
        Node(
            package='robot_parking',
            executable='odometry_node',
            name='odometry_node',
            output='screen',
            parameters=[]
        ),
        
        # Main Node (Lane + Sign + Parking)
        Node(
            package='robot_parking',
            executable='main_node',
            name='main_node',
            output='screen',
            parameters=[]
        ),
        
    ])