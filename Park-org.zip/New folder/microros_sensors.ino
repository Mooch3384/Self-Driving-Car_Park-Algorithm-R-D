/*
 * ESP32 MicroROS: Ultrasonic Sensor + Encoder Publisher
 * 
 * Publishes:
 *   /ultrasonic/distance (Float32) - Distance in cm
 *   /encoder_pulses (Int32) - Raw pulse count
 * 
 * Hardware:
 *   - HC-SR04 Ultrasonic sensor
 *   - 16 PPR Optical encoder
 */

#include <micro_ros_arduino.h>
#include <stdio.h>
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <std_msgs/msg/float32.h>
#include <std_msgs/msg/int32.h>
#include <std_msgs/msg/int8.h>

// ═══════════════════════════════════════════════════════════════════════════
// PIN DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

// Ultrasonic sensor
#define ULTRASONIC_TRIG     5
#define ULTRASONIC_ECHO     18

// Encoder
#define ENCODER_PIN_A       19
#define ENCODER_PIN_B       21

// Motor driver
#define MOTOR_PWM           22
#define MOTOR_DIR1          23
#define MOTOR_DIR2          25

// Servo
#define SERVO_PIN           26

// LED for status
#define LED_PIN             2

// ═══════════════════════════════════════════════════════════════════════════
// ROS OBJECTS
// ═══════════════════════════════════════════════════════════════════════════

rcl_publisher_t ultrasonic_pub;
rcl_publisher_t encoder_pub;
rcl_subscription_t servo_sub;
rcl_subscription_t motor_sub;

std_msgs__msg__Float32 ultrasonic_msg;
std_msgs__msg__Int32 encoder_msg;
std_msgs__msg__Int8 servo_msg;
std_msgs__msg__Int8 motor_msg;

rclc_executor_t executor;
rclc_support_t support;
rcl_allocator_t allocator;
rcl_node_t node;
rcl_timer_t timer;

// ═══════════════════════════════════════════════════════════════════════════
// ENCODER VARIABLES
// ═══════════════════════════════════════════════════════════════════════════

volatile long encoder_pulses = 0;
volatile int last_a = 0;
volatile int last_b = 0;

// ═══════════════════════════════════════════════════════════════════════════
// FUNCTION DECLARATIONS
// ═══════════════════════════════════════════════════════════════════════════

void IRAM_ATTR encoder_isr_a();
void IRAM_ATTR encoder_isr_b();
float read_ultrasonic();
void timer_callback(rcl_timer_t *timer, int64_t last_call_time);
void servo_callback(const void *msg_in);
void motor_callback(const void *msg_in);
void set_motor(int speed);
void set_servo(int angle);

// ═══════════════════════════════════════════════════════════════════════════
// ENCODER INTERRUPT HANDLERS
// ═══════════════════════════════════════════════════════════════════════════

void IRAM_ATTR encoder_isr_a() {
    int a = digitalRead(ENCODER_PIN_A);
    int b = digitalRead(ENCODER_PIN_B);
    
    if (a != last_a) {
        if (a == b) {
            encoder_pulses++;
        } else {
            encoder_pulses--;
        }
        last_a = a;
    }
}

void IRAM_ATTR encoder_isr_b() {
    int a = digitalRead(ENCODER_PIN_A);
    int b = digitalRead(ENCODER_PIN_B);
    
    if (b != last_b) {
        if (a != b) {
            encoder_pulses++;
        } else {
            encoder_pulses--;
        }
        last_b = b;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// ULTRASONIC SENSOR
// ═══════════════════════════════════════════════════════════════════════════

float read_ultrasonic() {
    // Send trigger pulse
    digitalWrite(ULTRASONIC_TRIG, LOW);
    delayMicroseconds(2);
    digitalWrite(ULTRASONIC_TRIG, HIGH);
    delayMicroseconds(10);
    digitalWrite(ULTRASONIC_TRIG, LOW);
    
    // Read echo pulse
    long duration = pulseIn(ULTRASONIC_ECHO, HIGH, 30000);
    
    // Calculate distance in cm
    // Speed of sound = 343 m/s = 0.0343 cm/us
    // Distance = (time * speed) / 2
    if (duration == 0) {
        return 999.0;  // No echo
    }
    
    float distance = (duration * 0.0343) / 2.0;
    return distance;
}

// ═══════════════════════════════════════════════════════════════════════════
// MOTOR CONTROL
// ═══════════════════════════════════════════════════════════════════════════

void set_motor(int speed) {
    // Speed: -255 to +255
    // Negative = reverse
    
    if (speed > 0) {
        digitalWrite(MOTOR_DIR1, HIGH);
        digitalWrite(MOTOR_DIR2, LOW);
        analogWrite(MOTOR_PWM, min(speed * 20, 255));
    } else if (speed < 0) {
        digitalWrite(MOTOR_DIR1, LOW);
        digitalWrite(MOTOR_DIR2, HIGH);
        analogWrite(MOTOR_PWM, min(-speed * 20, 255));
    } else {
        digitalWrite(MOTOR_DIR1, LOW);
        digitalWrite(MOTOR_DIR2, LOW);
        analogWrite(MOTOR_PWM, 0);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// SERVO CONTROL
// ═══════════════════════════════════════════════════════════════════════════

void set_servo(int angle) {
    // Angle: -6 to +6 (corresponds to -45 to +45 degrees)
    // Map to servo PWM (typically 1000-2000us)
    
    int pulse_width = map(angle, -6, 6, 1000, 2000);
    
    // Write servo position
    // Using ledcWrite for ESP32
    ledcWrite(0, pulse_width);
}

// ═══════════════════════════════════════════════════════════════════════════
// ROS CALLBACKS
// ═══════════════════════════════════════════════════════════════════════════

void timer_callback(rcl_timer_t *timer, int64_t last_call_time) {
    RCLC_UNUSED(last_call_time);
    
    if (timer != NULL) {
        // Read and publish ultrasonic distance
        ultrasonic_msg.data = read_ultrasonic();
        rcl_publish(&ultrasonic_pub, &ultrasonic_msg, NULL);
        
        // Publish encoder pulses
        encoder_msg.data = encoder_pulses;
        rcl_publish(&encoder_pub, &encoder_msg, NULL);
        
        // Blink LED to show activity
        digitalWrite(LED_PIN, !digitalRead(LED_PIN));
    }
}

void servo_callback(const void *msg_in) {
    const std_msgs__msg__Int8 *msg = (const std_msgs__msg__Int8 *)msg_in;
    set_servo(msg->data);
}

void motor_callback(const void *msg_in) {
    const std_msgs__msg__Int8 *msg = (const std_msgs__msg__Int8 *)msg_in;
    set_motor(msg->data);
}

// ═══════════════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════════════

void setup() {
    // GPIO Setup
    pinMode(ULTRASONIC_TRIG, OUTPUT);
    pinMode(ULTRASONIC_ECHO, INPUT);
    pinMode(ENCODER_PIN_A, INPUT_PULLUP);
    pinMode(ENCODER_PIN_B, INPUT_PULLUP);
    pinMode(MOTOR_PWM, OUTPUT);
    pinMode(MOTOR_DIR1, OUTPUT);
    pinMode(MOTOR_DIR2, OUTPUT);
    pinMode(LED_PIN, OUTPUT);
    
    // Servo PWM setup (ESP32)
    ledcSetup(0, 50, 16);  // Channel 0, 50Hz, 16-bit
    ledcAttachPin(SERVO_PIN, 0);
    
    // Encoder interrupts
    attachInterrupt(digitalPinToInterrupt(ENCODER_PIN_A), encoder_isr_a, CHANGE);
    attachInterrupt(digitalPinToInterrupt(ENCODER_PIN_B), encoder_isr_b, CHANGE);
    
    // Initialize motors stopped
    set_motor(0);
    set_servo(0);
    
    // MicroROS transport
    set_microros_transports();
    
    // Wait for agent connection
    delay(2000);
    
    // Initialize ROS
    allocator = rcl_get_default_allocator();
    rclc_support_init(&support, 0, NULL, &allocator);
    
    // Create node
    rclc_node_init_default(&node, "esp32_node", "", &support);
    
    // Create publishers
    rclc_publisher_init_default(
        &ultrasonic_pub,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Float32),
        "/ultrasonic/distance"
    );
    
    rclc_publisher_init_default(
        &encoder_pub,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Int32),
        "/encoder_pulses"
    );
    
    // Create subscribers
    rclc_subscription_init_default(
        &servo_sub,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Int8),
        "/servo"
    );
    
    rclc_subscription_init_default(
        &motor_sub,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Int8),
        "/motor_speed"
    );
    
    // Create timer (50ms = 20Hz)
    rclc_timer_init_default(
        &timer,
        &support,
        RCL_MS_TO_NS(50),
        timer_callback
    );
    
    // Create executor
    rclc_executor_init(&executor, &support.context, 3, &allocator);
    rclc_executor_add_timer(&executor, &timer);
    rclc_executor_add_subscription(&executor, &servo_sub, &servo_msg, 
                                   &servo_callback, ON_NEW_DATA);
    rclc_executor_add_subscription(&executor, &motor_sub, &motor_msg, 
                                   &motor_callback, ON_NEW_DATA);
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN LOOP
// ═══════════════════════════════════════════════════════════════════════════

void loop() {
    rclc_executor_spin_some(&executor, RCL_MS_TO_NS(10));
}