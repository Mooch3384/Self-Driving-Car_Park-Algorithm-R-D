#!/usr/bin/env python3
"""
Configuration Parameters for Autonomous Parking Robot
All tunable parameters in one place
"""

import math


class RobotConfig:
    """Robot physical parameters"""
    
    # Dimensions (cm)
    ROBOT_LENGTH = 20.0
    ROBOT_WIDTH = 18.0
    WHEEL_DIAMETER = 7.0
    
    # Encoder
    PULSES_PER_REV = 16
    WHEEL_CIRCUMFERENCE = math.pi * WHEEL_DIAMETER  # 21.99 cm
    DISTANCE_PER_PULSE = WHEEL_CIRCUMFERENCE / PULSES_PER_REV  # 1.374 cm
    
    # Steering
    MAX_STEERING_VALUE = 6  # corresponds to ±45 degrees
    

class SensorConfig:
    """Sensor thresholds and ranges"""
    
    # Ultrasonic (cm)
    OBSTACLE_THRESHOLD = 10.0      # Distance to detect obstacle
    MIN_SAFE_DISTANCE = 3.0        # Minimum safe distance
    MAX_SENSOR_RANGE = 25.0        # Maximum reliable range
    SPACE_START_THRESHOLD = 15.0   # Threshold to detect space start
    
    # Alignment
    ALIGNMENT_SAMPLES = 4          # Number of samples for alignment check
    ALIGNMENT_INTERVAL = 3.0       # Distance between samples (cm)
    MAX_ALIGNMENT_ERROR = 1.5      # Max allowed variance (cm)


class ParkingConfig:
    """Parking algorithm parameters"""
    
    # Space requirements (cm)
    MIN_PARKING_SPACE = 30.0       # Minimum: robot length + 10
    IDEAL_PARKING_SPACE = 35.0     # Comfortable space
    MAX_SEARCH_DISTANCE = 100.0    # Maximum search distance
    
    # Positioning (cm)
    IDEAL_DIST_FROM_OBS2 = 10.0    # Half robot length
    IDEAL_LATERAL_DISTANCE = 7.0   # Side clearance
    POSITION_TOLERANCE = 2.0       # Acceptable error
    
    # Maneuver distances (cm)
    BACKUP_DISTANCE_STEP1 = 25.0   # First reverse
    STRAIGHTEN_DISTANCE = 18.0     # Second reverse (straighten)
    
    # Attempts
    MAX_PARKING_ATTEMPTS = 3
    
    # AprilTag
    PARKING_TAG_ID = 10


class SpeedConfig:
    """Speed settings"""
    
    # Lane following
    STRAIGHT_SPEED = 12
    TURN_SPEED = 6
    RECOVERY_SPEED = 4
    
    # Parking
    SCAN_SPEED = 8
    PARKING_SPEED = 5
    ALIGN_SPEED = 4


class TopicConfig:
    """ROS2 topic names"""
    
    # Inputs
    CAMERA_TOPIC = '/camera/image_raw'
    ULTRASONIC_TOPIC = '/ultrasonic/distance'
    ENCODER_TOPIC = '/encoder_pulses'
    
    # Outputs
    SERVO_TOPIC = '/servo'
    MOTOR_TOPIC = '/motor_speed'
    
    # Odometry
    ODOMETRY_DISTANCE_TOPIC = '/odometry/distance'
    ODOMETRY_TRIP_TOPIC = '/odometry/trip_distance'
    ODOMETRY_VELOCITY_TOPIC = '/odometry/velocity'
    ODOMETRY_RESET_TOPIC = '/odometry/reset'