#!/usr/bin/env python3
"""
Autonomous Parallel Parking Controller
Implements a state machine for parallel parking maneuver

States:
    Phase 1 - Scan & Discover
    Phase 2 - Positioning  
    Phase 3 - Parking Maneuver
"""

from enum import Enum
import time

from config import RobotConfig, SensorConfig, ParkingConfig, SpeedConfig


class ParkingState(Enum):
    """Parking state machine states"""
    
    # Control states
    DISABLED = 0
    IDLE = 1
    
    # Phase 1: Scan & Discover
    CHECK_INITIAL_DISTANCE = 10
    CHECK_ALIGNMENT = 11
    FIX_ALIGNMENT = 12
    SCAN_FOR_OBSTACLE1 = 13
    FIND_SPACE_START = 14
    FIND_OBSTACLE2 = 15
    VERIFY_SPACE_SIZE = 16
    
    # Phase 2: Positioning
    POSITION_FORWARD = 20
    ADJUST_LATERAL = 21
    ADJUST_LONGITUDINAL = 22
    FINAL_ALIGNMENT_CHECK = 23
    READY_TO_PARK = 24
    
    # Phase 3: Parking Maneuver
    PARK_STEP1_REVERSE_RIGHT = 30
    PARK_STEP2_REVERSE_LEFT = 31
    VERIFY_PARALLEL = 32
    FINAL_ADJUSTMENT = 33
    
    # End states
    COMPLETED = 40
    FAILED = 41
    
    # Error states
    ERROR_TOO_CLOSE = 50
    ERROR_TOO_FAR = 51
    ERROR_SPACE_TOO_SMALL = 52
    ERROR_NO_OBSTACLE2 = 53
    ERROR_ALIGNMENT_FAILED = 54


class ParkingController:
    """Main parking controller with state machine"""
    
    def __init__(self, logger=None):
        self.logger = logger
        
        # Configuration
        self.robot = RobotConfig()
        self.sensor = SensorConfig()
        self.parking = ParkingConfig()
        self.speed = SpeedConfig()
        
        # State
        self.state = ParkingState.DISABLED
        self.prev_state = ParkingState.DISABLED
        
        # Sensor data
        self.ultrasonic_distance = float('inf')
        self.total_distance = 0.0
        
        # State tracking
        self.state_start_distance = 0.0
        self.state_start_time = 0.0
        
        # Parking data
        self.obstacle1_position = None
        self.space_start_position = None
        self.obstacle2_position = None
        self.space_size = 0.0
        
        # Alignment data
        self.alignment_samples = []
        self.alignment_positions = []
        
        # Control outputs
        self.steering = 0
        self.speed_output = 0
        
        # Counters
        self.parking_attempts = 0
        self.alignment_attempts = 0
        
        # Flags
        self.parking_enabled = False
        self.parking_tag_detected = False
        
        self._log("Parking Controller initialized")

    def _log(self, message: str):
        """Log message"""
        if self.logger:
            self.logger.info(f'[PARKING] {message}')
        else:
            print(f'[PARKING] {message}')

    def _log_state_change(self):
        """Log state transition"""
        self._log(f'State: {self.prev_state.name} -> {self.state.name}')

    # ═══════════════════════════════════════════════════════════════════════
    # PUBLIC METHODS
    # ═══════════════════════════════════════════════════════════════════════
    
    def enable(self):
        """Enable parking mode"""
        if self.state == ParkingState.DISABLED:
            self._reset_parking_data()
            self.parking_enabled = True
            self._change_state(ParkingState.IDLE)
            self._log("Parking ENABLED")

    def disable(self):
        """Disable parking mode"""
        self.parking_enabled = False
        self._change_state(ParkingState.DISABLED)
        self.steering = 0
        self.speed_output = 0
        self._log("Parking DISABLED")

    def update(self, ultrasonic_cm: float, odometry_cm: float, 
               parking_tag_visible: bool = False) -> tuple:
        """
        Main update function - call every frame
        
        Args:
            ultrasonic_cm: Ultrasonic sensor distance in cm
            odometry_cm: Total distance traveled in cm
            parking_tag_visible: Whether parking AprilTag is visible
            
        Returns:
            tuple: (steering, speed)
        """
        # Update sensor data
        self.ultrasonic_distance = ultrasonic_cm
        self.total_distance = odometry_cm
        
        # Check for parking tag
        if parking_tag_visible and not self.parking_enabled:
            self.parking_tag_detected = True
            self.enable()
        
        # State machine
        if self.state == ParkingState.DISABLED:
            return self._stop()
            
        elif self.state == ParkingState.IDLE:
            return self._state_idle()
        
        # Phase 1: Scan & Discover
        elif self.state == ParkingState.CHECK_INITIAL_DISTANCE:
            return self._state_check_initial()
            
        elif self.state == ParkingState.CHECK_ALIGNMENT:
            return self._state_check_alignment()
            
        elif self.state == ParkingState.FIX_ALIGNMENT:
            return self._state_fix_alignment()
            
        elif self.state == ParkingState.SCAN_FOR_OBSTACLE1:
            return self._state_scan_obstacle1()
            
        elif self.state == ParkingState.FIND_SPACE_START:
            return self._state_find_space_start()
            
        elif self.state == ParkingState.FIND_OBSTACLE2:
            return self._state_find_obstacle2()
            
        elif self.state == ParkingState.VERIFY_SPACE_SIZE:
            return self._state_verify_space()
        
        # Phase 2: Positioning
        elif self.state == ParkingState.POSITION_FORWARD:
            return self._state_position_forward()
            
        elif self.state == ParkingState.ADJUST_LATERAL:
            return self._state_adjust_lateral()
            
        elif self.state == ParkingState.ADJUST_LONGITUDINAL:
            return self._state_adjust_longitudinal()
            
        elif self.state == ParkingState.FINAL_ALIGNMENT_CHECK:
            return self._state_final_alignment()
            
        elif self.state == ParkingState.READY_TO_PARK:
            return self._state_ready_to_park()
        
        # Phase 3: Parking Maneuver
        elif self.state == ParkingState.PARK_STEP1_REVERSE_RIGHT:
            return self._state_park_step1()
            
        elif self.state == ParkingState.PARK_STEP2_REVERSE_LEFT:
            return self._state_park_step2()
            
        elif self.state == ParkingState.VERIFY_PARALLEL:
            return self._state_verify_parallel()
            
        elif self.state == ParkingState.FINAL_ADJUSTMENT:
            return self._state_final_adjustment()
        
        # End states
        elif self.state == ParkingState.COMPLETED:
            return self._state_completed()
            
        elif self.state == ParkingState.FAILED:
            return self._state_failed()
        
        # Error states
        elif self.state.value >= 50:
            return self._handle_error_state()
        
        return self._stop()

    def is_active(self) -> bool:
        """Check if parking is in progress"""
        return self.state not in [
            ParkingState.DISABLED,
            ParkingState.COMPLETED,
            ParkingState.FAILED
        ]

    def is_completed(self) -> bool:
        """Check if parking completed successfully"""
        return self.state == ParkingState.COMPLETED

    def is_failed(self) -> bool:
        """Check if parking failed"""
        return self.state == ParkingState.FAILED

    def get_status(self) -> dict:
        """Get current status"""
        return {
            'state': self.state.name,
            'enabled': self.parking_enabled,
            'ultrasonic': self.ultrasonic_distance,
            'trip_distance': self._get_trip_distance(),
            'space_size': self.space_size,
            'attempts': self.parking_attempts,
            'steering': self.steering,
            'speed': self.speed_output
        }

    # ═══════════════════════════════════════════════════════════════════════
    # PRIVATE HELPER METHODS
    # ═══════════════════════════════════════════════════════════════════════
    
    def _change_state(self, new_state: ParkingState):
        """Change to new state"""
        if new_state != self.state:
            self.prev_state = self.state
            self.state = new_state
            self.state_start_distance = self.total_distance
            self.state_start_time = time.time()
            self._log_state_change()

    def _get_trip_distance(self) -> float:
        """Get distance traveled since state start"""
        return self.total_distance - self.state_start_distance

    def _reset_trip(self):
        """Reset trip distance"""
        self.state_start_distance = self.total_distance

    def _reset_parking_data(self):
        """Reset all parking data"""
        self.obstacle1_position = None
        self.space_start_position = None
        self.obstacle2_position = None
        self.space_size = 0.0
        self.alignment_samples = []
        self.alignment_positions = []
        self.parking_attempts = 0
        self.alignment_attempts = 0

    # ═══════════════════════════════════════════════════════════════════════
    # OUTPUT METHODS
    # ═══════════════════════════════════════════════════════════════════════
    
    def _stop(self) -> tuple:
        """Stop robot"""
        self.steering = 0
        self.speed_output = 0
        return (0, 0)

    def _forward(self, speed: int = None, steering: int = 0) -> tuple:
        """Move forward"""
        if speed is None:
            speed = self.speed.SCAN_SPEED
        self.steering = steering
        self.speed_output = speed
        return (steering, speed)

    def _backward(self, speed: int = None, steering: int = 0) -> tuple:
        """Move backward (negative speed)"""
        if speed is None:
            speed = self.speed.PARKING_SPEED
        self.steering = steering
        self.speed_output = -speed
        return (steering, -speed)

    # ═══════════════════════════════════════════════════════════════════════
    # STATE HANDLERS - IDLE
    # ═══════════════════════════════════════════════════════════════════════
    
    def _state_idle(self) -> tuple:
        """Waiting for activation"""
        if self.parking_enabled:
            self._change_state(ParkingState.CHECK_INITIAL_DISTANCE)
        return self._stop()

    # ═══════════════════════════════════════════════════════════════════════
    # STATE HANDLERS - PHASE 1: SCAN & DISCOVER
    # ═══════════════════════════════════════════════════════════════════════
    
    def _state_check_initial(self) -> tuple:
        """Check initial distance from obstacles"""
        dist = self.ultrasonic_distance
        
        if dist < self.sensor.MIN_SAFE_DISTANCE:
            self._log(f"Too close: {dist:.1f}cm")
            self._change_state(ParkingState.ERROR_TOO_CLOSE)
            return self._stop()
        
        elif dist > self.sensor.MAX_SENSOR_RANGE:
            self._log(f"Too far: {dist:.1f}cm")
            self._change_state(ParkingState.ERROR_TOO_FAR)
            return self._stop()
        
        else:
            self._log(f"Initial distance OK: {dist:.1f}cm")
            self.alignment_samples = []
            self.alignment_positions = []
            self._reset_trip()
            self._change_state(ParkingState.CHECK_ALIGNMENT)
            return self._forward(self.speed.SCAN_SPEED)

    def _state_check_alignment(self) -> tuple:
        """Check if robot is parallel to obstacles"""
        trip = self._get_trip_distance()
        
        # Take samples at regular intervals
        expected_samples = int(trip / self.sensor.ALIGNMENT_INTERVAL)
        
        if expected_samples > len(self.alignment_samples):
            self.alignment_samples.append(self.ultrasonic_distance)
            self.alignment_positions.append(self.total_distance)
            self._log(f"Alignment sample {len(self.alignment_samples)}: "
                     f"{self.ultrasonic_distance:.1f}cm")
        
        # After collecting enough samples
        if len(self.alignment_samples) >= self.sensor.ALIGNMENT_SAMPLES:
            variance = self.alignment_samples[-1] - self.alignment_samples[0]
            
            if abs(variance) > self.sensor.MAX_ALIGNMENT_ERROR:
                self._log(f"Misaligned! Variance: {variance:.1f}cm")
                self._change_state(ParkingState.FIX_ALIGNMENT)
                return self._stop()
            else:
                self._log("Alignment OK")
                self._reset_trip()
                
                # Decide next state based on distance
                if self.ultrasonic_distance < self.sensor.OBSTACLE_THRESHOLD:
                    self._change_state(ParkingState.SCAN_FOR_OBSTACLE1)
                else:
                    self.space_start_position = self.total_distance
                    self._change_state(ParkingState.FIND_OBSTACLE2)
                    
                return self._forward(self.speed.SCAN_SPEED)
        
        return self._forward(self.speed.SCAN_SPEED)

    def _state_fix_alignment(self) -> tuple:
        """Fix robot alignment"""
        variance = self.alignment_samples[-1] - self.alignment_samples[0]
        
        # Determine correction direction
        if variance > 0:
            steering = self.robot.MAX_STEERING_VALUE // 2  # Turn right
        else:
            steering = -self.robot.MAX_STEERING_VALUE // 2  # Turn left
        
        trip = self._get_trip_distance()
        
        if trip < 10:  # Move 10cm for correction
            return self._forward(self.speed.ALIGN_SPEED, steering)
        else:
            self.alignment_attempts += 1
            if self.alignment_attempts >= 3:
                self._change_state(ParkingState.ERROR_ALIGNMENT_FAILED)
                return self._stop()
            
            self.alignment_samples = []
            self.alignment_positions = []
            self._reset_trip()
            self._change_state(ParkingState.CHECK_ALIGNMENT)
            return self._forward(self.speed.SCAN_SPEED)

    def _state_scan_obstacle1(self) -> tuple:
        """Scan for first obstacle"""
        dist = self.ultrasonic_distance
        trip = self._get_trip_distance()
        
        # Timeout
        if trip > self.parking.MAX_SEARCH_DISTANCE:
            self._log("Timeout: No obstacle 1 found")
            self.space_start_position = self.total_distance
            self._change_state(ParkingState.FIND_OBSTACLE2)
            return self._forward(self.speed.SCAN_SPEED)
        
        # Detect obstacle then space
        if self.obstacle1_position is None:
            if dist < self.sensor.OBSTACLE_THRESHOLD:
                self.obstacle1_position = self.total_distance
                self._log(f"Obstacle 1 at {self.obstacle1_position:.1f}cm")
        else:
            if dist > self.sensor.SPACE_START_THRESHOLD:
                self.space_start_position = self.total_distance
                self._log(f"Space start at {self.space_start_position:.1f}cm")
                self._reset_trip()
                self._change_state(ParkingState.FIND_OBSTACLE2)
        
        return self._forward(self.speed.SCAN_SPEED)

    def _state_find_space_start(self) -> tuple:
        """Find the start of parking space"""
        dist = self.ultrasonic_distance
        trip = self._get_trip_distance()
        
        if dist > self.sensor.SPACE_START_THRESHOLD:
            self.space_start_position = self.total_distance
            self._log(f"Space start at {self.space_start_position:.1f}cm")
            self._reset_trip()
            self._change_state(ParkingState.FIND_OBSTACLE2)
        
        if trip > self.parking.MAX_SEARCH_DISTANCE:
            self._change_state(ParkingState.ERROR_SPACE_TOO_SMALL)
        
        return self._forward(self.speed.SCAN_SPEED)

    def _state_find_obstacle2(self) -> tuple:
        """Find second obstacle (end of parking space)"""
        dist = self.ultrasonic_distance
        trip = self._get_trip_distance()
        
        # Timeout
        if trip > self.parking.MAX_SEARCH_DISTANCE:
            self._log("Timeout: No obstacle 2 found")
            self._change_state(ParkingState.ERROR_NO_OBSTACLE2)
            return self._stop()
        
        # Detect obstacle 2
        if dist < self.sensor.OBSTACLE_THRESHOLD:
            self.obstacle2_position = self.total_distance
            self.space_size = self.obstacle2_position - self.space_start_position
            self._log(f"Obstacle 2 found! Space size: {self.space_size:.1f}cm")
            self._change_state(ParkingState.VERIFY_SPACE_SIZE)
            return self._stop()
        
        return self._forward(self.speed.SCAN_SPEED)

    def _state_verify_space(self) -> tuple:
        """Verify parking space is large enough"""
        if self.space_size < self.parking.MIN_PARKING_SPACE:
            self._log(f"Space too small: {self.space_size:.1f}cm < "
                     f"{self.parking.MIN_PARKING_SPACE}cm")
            # Continue searching
            self.space_start_position = None
            self.obstacle2_position = None
            self._reset_trip()
            self._change_state(ParkingState.SCAN_FOR_OBSTACLE1)
            return self._forward(self.speed.SCAN_SPEED)
        
        self._log(f"Space verified: {self.space_size:.1f}cm")
        self._reset_trip()
        self._change_state(ParkingState.POSITION_FORWARD)
        return self._forward(self.speed.SCAN_SPEED)

    # ═══════════════════════════════════════════════════════════════════════
    # STATE HANDLERS - PHASE 2: POSITIONING
    # ═══════════════════════════════════════════════════════════════════════
    
    def _state_position_forward(self) -> tuple:
        """Position robot next to obstacle 2"""
        trip = self._get_trip_distance()
        target = self.parking.IDEAL_DIST_FROM_OBS2
        
        if trip >= target:
            self._log(f"Positioned: {trip:.1f}cm forward")
            self._change_state(ParkingState.ADJUST_LATERAL)
            return self._stop()
        
        return self._forward(self.speed.PARKING_SPEED)

    def _state_adjust_lateral(self) -> tuple:
        """Adjust lateral (side) distance"""
        dist = self.ultrasonic_distance
        
        if dist < self.sensor.MIN_SAFE_DISTANCE:
            self._change_state(ParkingState.ERROR_TOO_CLOSE)
            return self._stop()
        
        if dist > self.sensor.MAX_SENSOR_RANGE:
            self._change_state(ParkingState.ERROR_TOO_FAR)
            return self._stop()
        
        self._log(f"Lateral distance OK: {dist:.1f}cm")
        self._change_state(ParkingState.FINAL_ALIGNMENT_CHECK)
        return self._stop()

    def _state_adjust_longitudinal(self) -> tuple:
        """Adjust longitudinal (forward/back) distance"""
        # This can be expanded for more precise positioning
        self._change_state(ParkingState.FINAL_ALIGNMENT_CHECK)
        return self._stop()

    def _state_final_alignment(self) -> tuple:
        """Final alignment check before parking"""
        trip = self._get_trip_distance()
        
        # Take 2 samples
        if len(self.alignment_samples) == 0:
            self.alignment_samples = [self.ultrasonic_distance]
            self._reset_trip()
            return self._forward(self.speed.ALIGN_SPEED)
        
        if trip >= 5:  # After 5cm
            self.alignment_samples.append(self.ultrasonic_distance)
            variance = abs(self.alignment_samples[-1] - self.alignment_samples[0])
            
            if variance > 1.0:
                self._log(f"Not parallel: variance={variance:.1f}cm")
                self.alignment_samples = []
                self._change_state(ParkingState.FIX_ALIGNMENT)
                return self._stop()
            
            self._log("Parallel confirmed - Ready to park")
            self._change_state(ParkingState.READY_TO_PARK)
            return self._stop()
        
        return self._forward(self.speed.ALIGN_SPEED)

    def _state_ready_to_park(self) -> tuple:
        """Ready to start parking maneuver"""
        self._log("=" * 40)
        self._log("STARTING PARKING MANEUVER")
        self._log("=" * 40)
        self._reset_trip()
        self.parking_attempts += 1
        self._change_state(ParkingState.PARK_STEP1_REVERSE_RIGHT)
        return self._stop()

    # ═══════════════════════════════════════════════════════════════════════
    # STATE HANDLERS - PHASE 3: PARKING MANEUVER
    # ═══════════════════════════════════════════════════════════════════════
    
    def _state_park_step1(self) -> tuple:
        """Step 1: Reverse with right steering"""
        trip = self._get_trip_distance()
        dist = self.ultrasonic_distance
        target = self.parking.BACKUP_DISTANCE_STEP1
        
        # Stop conditions
        if trip >= target:
            self._log(f"Step 1 complete: {trip:.1f}cm")
            self._reset_trip()
            self._change_state(ParkingState.PARK_STEP2_REVERSE_LEFT)
            return self._stop()
        
        if dist < self.sensor.MIN_SAFE_DISTANCE:
            self._log(f"Close to obstacle: {dist:.1f}cm")
            self._reset_trip()
            self._change_state(ParkingState.PARK_STEP2_REVERSE_LEFT)
            return self._stop()
        
        # Continue: reverse with right steering
        steering = self.robot.MAX_STEERING_VALUE  # +6 = right
        return self._backward(self.speed.PARKING_SPEED, steering)

    def _state_park_step2(self) -> tuple:
        """Step 2: Reverse with left steering (straighten)"""
        trip = self._get_trip_distance()
        target = self.parking.STRAIGHTEN_DISTANCE
        
        if trip >= target:
            self._log(f"Step 2 complete: {trip:.1f}cm")
            self._change_state(ParkingState.VERIFY_PARALLEL)
            return self._stop()
        
        # Continue: reverse with left steering
        steering = -self.robot.MAX_STEERING_VALUE  # -6 = left
        return self._backward(self.speed.PARKING_SPEED, steering)

    def _state_verify_parallel(self) -> tuple:
        """Verify robot is parallel after maneuver"""
        self.alignment_samples = []
        self._reset_trip()
        
        # Take first sample
        self.alignment_samples.append(self.ultrasonic_distance)
        
        trip = self._get_trip_distance()
        
        if trip < 5:
            return self._forward(self.speed.ALIGN_SPEED)
        
        # Take second sample
        self.alignment_samples.append(self.ultrasonic_distance)
        variance = abs(self.alignment_samples[-1] - self.alignment_samples[0])
        
        if variance < 0.5:
            self._log("Parking successful!")
            self._change_state(ParkingState.FINAL_ADJUSTMENT)
        else:
            self._log(f"Not parallel: variance={variance:.1f}cm")
            if self.parking_attempts < self.parking.MAX_PARKING_ATTEMPTS:
                self._log(f"Retry {self.parking_attempts + 1}/"
                         f"{self.parking.MAX_PARKING_ATTEMPTS}")
                self._change_state(ParkingState.READY_TO_PARK)
            else:
                self._change_state(ParkingState.FAILED)
        
        return self._stop()

    def _state_final_adjustment(self) -> tuple:
        """Final position adjustment"""
        dist = self.ultrasonic_distance
        
        if dist < self.sensor.MIN_SAFE_DISTANCE:
            return self._forward(self.speed.ALIGN_SPEED)
        
        if dist > 15:
            return self._backward(self.speed.ALIGN_SPEED)
        
        self._change_state(ParkingState.COMPLETED)
        return self._stop()

    # ═══════════════════════════════════════════════════════════════════════
    # STATE HANDLERS - END STATES
    # ═══════════════════════════════════════════════════════════════════════
    
    def _state_completed(self) -> tuple:
        """Parking completed successfully"""
        self._log("=" * 40)
        self._log("PARKING COMPLETED SUCCESSFULLY")
        self._log("=" * 40)
        return self._stop()

    def _state_failed(self) -> tuple:
        """Parking failed"""
        self._log("=" * 40)
        self._log("PARKING FAILED")
        self._log("=" * 40)
        return self._stop()

    # ═══════════════════════════════════════════════════════════════════════
    # STATE HANDLERS - ERROR STATES
    # ═══════════════════════════════════════════════════════════════════════
    
    def _handle_error_state(self) -> tuple:
        """Handle error states with recovery"""
        
        if self.state == ParkingState.ERROR_TOO_CLOSE:
            # Too close - move away
            trip = self._get_trip_distance()
            if trip < 5:
                return self._forward(self.speed.ALIGN_SPEED,
                                    -self.robot.MAX_STEERING_VALUE // 2)
            else:
                self._change_state(ParkingState.CHECK_INITIAL_DISTANCE)
                return self._stop()
        
        elif self.state == ParkingState.ERROR_TOO_FAR:
            # Too far - move closer
            if self.ultrasonic_distance > self.sensor.MAX_SENSOR_RANGE:
                return self._forward(self.speed.ALIGN_SPEED,
                                    self.robot.MAX_STEERING_VALUE // 2)
            else:
                self._change_state(ParkingState.CHECK_INITIAL_DISTANCE)
                return self._stop()
        
        elif self.state == ParkingState.ERROR_SPACE_TOO_SMALL:
            self._log("Continuing search for larger space")
            self._reset_parking_data()
            self._change_state(ParkingState.SCAN_FOR_OBSTACLE1)
            return self._forward(self.speed.SCAN_SPEED)
        
        elif self.state == ParkingState.ERROR_NO_OBSTACLE2:
            self._log("No obstacle 2 - restarting scan")
            self._reset_parking_data()
            self._change_state(ParkingState.SCAN_FOR_OBSTACLE1)
            return self._forward(self.speed.SCAN_SPEED)
        
        elif self.state == ParkingState.ERROR_ALIGNMENT_FAILED:
            self._log("Alignment failed - aborting")
            self._change_state(ParkingState.FAILED)
            return self._stop()
        
        return self._stop()